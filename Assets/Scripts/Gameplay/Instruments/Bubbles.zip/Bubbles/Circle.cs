using System;
using UnityEngine;

namespace Gameplay.Instruments.Bubble
{
    [System.Serializable]
    public partial class Circle : BaseInstrument
    {
        public bool MultiBallUsed { get; private set; }
        [SerializeField, Range(0.1f, 1f)] float BubbleSpeed; 
        [SerializeField, Range(0, 1.0f)] protected float mineCollisionSizeMultiplier = 0.5f;
        [SerializeField] Vector2 SecondaryBubbleLocalPos;
        [Header("Sub Components"), SerializeField] Collider2D BubbleSwitchButton;
        [SerializeField] SwitchAbilityIcon UserHelp;
        [SerializeField] Pools.BubblePool BubblePool;
        [SerializeField] MovingBubbleEffect MovingBubbles;
        [SerializeField] CollisionEffect Collisions;
        [SerializeField] Transform MultiBallOnScene;
        Gameplay.Bubble actualBubble, secondaryBubble;
        bool isBubblesOnReload, userWannaShoot;
        Coroutine CircleRotateAnimation;

        protected override int trajectoryCollisionsCount => 10;
        protected override float collisionSizeMultiplier => mineCollisionSizeMultiplier;
        public override bool RequireDrawTrajectory => !User.UsingTouch || userWannaShoot;
        
        public override void ReactOnClickDown()
        { 
            userWannaShoot = true;
            if (User.UsingTouch) 
            {
                Trajectory?.ProcessRay(mouseClampedDirection);
            }
            else 
            {
                TryShoot();
            }
        }
        
        public override void ReactOnClickUp()
        {
            userWannaShoot = false;
            if (User.UsingTouch)
            {
                TryShoot();
            }
        }
        
        void PlaceBubblesAndRecolorTrajectory()
        {
            actualBubble.MyTransform.localPosition = Vector3.zero;
            secondaryBubble.MyTransform.localPosition = SecondaryBubbleLocalPos;
            
            Trajectory.ChangeColor(ColorPicker.GetColorByEnum(actualBubble.MyColor));
        }

        public override void ReactOnAdditional()
        {
            RotateBubbleCircle();
        }

        internal void UseMultiBall()
        {
            MultiBallUsed = true;
        }
    }
}