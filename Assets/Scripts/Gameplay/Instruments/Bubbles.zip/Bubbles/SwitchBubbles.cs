using System.Collections;
using UnityEngine;

namespace Gameplay.Instruments.Bubble
{
    public partial class Circle : BaseInstrument
    {
        void RotateBubbleCircle()
        {
            (secondaryBubble, actualBubble) = (actualBubble, secondaryBubble);
            if (CircleRotateAnimation != null)
            {
                User.StopCoroutine(CircleRotateAnimation);
            }
            CircleRotateAnimation = User.StartCoroutine(AnimateCircleRotation());
            UserHelp.ReceiveUserSwitched();
            Sounds.Play(Services.Audio.Sounds.SoundType.CircleBubbleSwitch);
            //SwitchSound.Play();
        }
        
        IEnumerator AnimateCircleRotation()
        {
            const int Steps = 20;
            var MidLine = SecondaryBubbleLocalPos * 0.5f;
            var L = MidLine.magnitude;
            var OldColor = ColorPicker.GetColorByEnum(secondaryBubble.MyColor);
            var NewColor = ColorPicker.GetColorByEnum(actualBubble.MyColor);
            for (int i = 1; i < Steps; i ++)
            {
                float Lerp = i/(float) Steps;
                var Shift = new Vector2(Mathf.Sin(180 * Lerp * Mathf.Deg2Rad), Mathf.Cos(180 * Lerp * Mathf.Deg2Rad)) * L;
                actualBubble.MyTransform.localPosition = MidLine - Shift;
                secondaryBubble.MyTransform.localPosition = MidLine + Shift;
                Trajectory.ChangeColor(Color.Lerp(OldColor, NewColor, Lerp));
                yield return Wait;
            }
            PlaceBubblesAndRecolorTrajectory();
            CircleRotateAnimation = null;
        }
    }
}