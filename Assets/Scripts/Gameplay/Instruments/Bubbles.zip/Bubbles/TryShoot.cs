using System.Collections;
using UnityEngine;

namespace Gameplay.Instruments.Bubble
{
    public partial class Circle : BaseInstrument
    {
        void TryShoot()
        {
            if (IsClickedToSwitchBubbleButton())
            {
                RotateBubbleCircle();
            }
            else
            {
                ShootBubble();
            }
            
            bool IsClickedToSwitchBubbleButton()
            {
                var Ray = User.GetScreenRayAtCursor();
                var Hit = Physics2D.Raycast(Ray.origin, Ray.direction, 100, 2);
                return Hit.collider == BubbleSwitchButton;
            }
        }
        
        void ShootBubble()
        {
            if (!User.IsClickedInGameField()) return;
            if (isBubblesOnReload) return;
            if (!instrumentShown) return;
            
            TryBreakSwitchAnimation();
            var flyTrajectory = new User.Trajectory(CollisionRadius, Field.TryResponseCollision, 1, trajectoryCollisionsCount);
            
            var bubble = actualBubble;
            actualBubble = null;
            
            MovingBubbles.ApplyParticleToMovingBubble(bubble);
            Sounds.Play(Services.Audio.Sounds.SoundType.BubbleShoot);
            //ShootSound.Play();
            StartCoroutine(AnimateBubbleFly(bubble.MyTransform, ProcessEndBubbleWay));
            StartCoroutine(AnimateBubblesShift(ColorPicker.GetColorByEnum(bubble.MyColor)));
        
            void TryBreakSwitchAnimation()
            {
                if (CircleRotateAnimation == null) return;
                User.StopCoroutine(CircleRotateAnimation);
                PlaceBubblesAndRecolorTrajectory();
            }
        
            IEnumerator AnimateBubbleFly(Transform Target, System.Action OnEnd)
            {
                User.CollisionType Col;
                flyTrajectory.PrepareFirst(User.transform.position, mouseClampedDirection);
                Target.position = flyTrajectory.PosOnWay;
                flyTrajectory.StepLengthOnWay = BubbleSpeed;
                while (!flyTrajectory.Completed)
                {
                    Col = flyTrajectory.TryStepAndCheckCollisions();
                    if (Col != Gameplay.User.CollisionType.None)
                    {
                        Collisions.ReactOnCollision(Col, flyTrajectory.CurrentCornerPointOnWay);
                    }
                    Target.position = flyTrajectory.PosOnWay;
                    yield return Wait;
                }
                OnEnd?.Invoke();
            }
            
            IEnumerator AnimateBubblesShift(Color OldColor, System.Action OnEnd = null)
            {
                isBubblesOnReload = true;
                var MainBubbleOld = secondaryBubble.MyTransform.position;
                var MainBubbleNew = User.transform.position;
                var SecBubbleOld = User.transform.position + (Vector3)OutOfViewPos;
                var SecBubbleNew = MainBubbleOld;
                actualBubble = secondaryBubble;
                secondaryBubble = GiveAndSetupBubble();
                var NewColor = ColorPicker.GetColorByEnum(actualBubble.MyColor);
                float Lerp = 0;
                for (int i = 0; i < 10; i ++)
                {
                    Lerp += .1f;
                    actualBubble.MyTransform.position = Vector3.Lerp(MainBubbleOld, MainBubbleNew, Lerp);
                    secondaryBubble.MyTransform.position = Vector3.Lerp(SecBubbleOld, SecBubbleNew, Lerp);
                    Trajectory.ChangeColor(Color.Lerp(OldColor, NewColor, Lerp));
                    yield return Wait;
                }
                PlaceBubblesAndRecolorTrajectory();
                isBubblesOnReload = false;
                OnEnd?.Invoke();
            }
            
            void ProcessEndBubbleWay()
            {
                MovingBubbles.DisableBubbleParticle();
                bubble.ActivateCollisions();
                flyTrajectory.StepLengthOnWay *= -1;
                Field.PlaceUserBubble(bubble, flyTrajectory);
                Field.TryFilterColor(ref actualBubble);
                Field.TryFilterColor(ref secondaryBubble);
            }
        }
    }
}